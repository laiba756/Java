// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
// Press Alt+Enter with your caret at the highlighted text to see how
// IntelliJ IDEA suggests fixing it.

//FOR INPUT
import java.util.*;
public class Main {
    public static void main(String[] args) {


        //OUTPUT
        //1. System is CLASS
        //2. println is like endl
       System.out.println("Assalamu alaikum Laiba\nkesi ho?");


//VARIABLES IN JAVA
        //INT
    int a=2;
    int b=-3;
    int s=a*b;
    System.out.println(s);
//STRING
        String l="ms";
        System.out.println(l);

        //FOR INPUT
        //1. USE lib: import java.util.*
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter your name:");

        String name= sc.next(); //next is for single word input

        String Fullname= sc.nextLine();  //pehlay lafz k bad wali line print kranay k liyay

        System.out.println("My name is:"+name);

        System.out.println("My full name is:"+Fullname);

//nextInt, nextfloat waghaira bhi use kr sktay
        int n=sc.nextInt();
        System.out.println(n);
    }
}