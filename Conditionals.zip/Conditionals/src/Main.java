// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

//*****************************************//
// Java program to illustrate if-else-if ladder
//*****************************************//
/*import java.util.*;
class ifelseDemo {
    public static void main(String args[])
    {
        int i = 200;

        if (i == 10)
            System.out.println("i is 10");
        else if (i == 15)
            System.out.println("i is 15");
        else if (i == 20)
            System.out.println("i is 20");
        else
            System.out.println("i is not present");
    }
}*/

//********************//
//SWITCH
/*package whatever //do not write package name here */

/*import java.util.*;

class GFG {
    public static void main (String[] args) {
        int num=20;
        switch(num){
            case 5 : System.out.println("It is 5");
                break;
            case 10 : System.out.println("It is 10");
                break;
            case 15 : System.out.println("It is 15");
                break;
            case 20 : System.out.println("It is 20");
                break;
            default: System.out.println("Not present");

        }
    }
}*/

//**************
// Java program to illustrate using
// continue in an if statement
/*import java.util.*;

class ContinueDemo {
    public static void main(String args[])
    {
        for (int i = 0; i < 10; i++) {
            // If the number is odd
            // skip and continue
            if (i % 2 != 0)
                continue;

            // If number is odd, print it
            System.out.print(i + " ");
        }
    }
}*/



//*******
// Java program to illustrate using return
import java.util.*;
public class Main{

    public static void main(String[] args) {
        boolean condition = false;     //JB TRUE KRO GAY TO AUR AYAY GA OUTPUT
        int result = multiply(5, 7, condition);
        System.out.println("Result: " + result);
    }

    public static int multiply(int num1, int num2, boolean condition) {
        if (condition) {
            System.out.println("Condition is true. Exiting early.");
            return 0;
        }

        int product = num1 * num2;
        return product;
    }
}






