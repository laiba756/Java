//input->operations->output

//In Java, every method must be part of some class that is different from languages like C, C++, and Python.

//return type say pehlay public static lga sktay
//functionname predefined function say ht kr rakho
import java.util.*;
import java.util.function.LongToIntFunction;

//BASIC FUNCTIONS
public class Main {
    public static void printMyName(String name) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        System.out.printf(name);
return;
    }
    public static int printSum(int n1,int n2) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        int sum=n1+n2;
       // System.out.printf(sum);
        return sum;
    }
    public static int printmul(int n1,int n2) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        int mul=n1*n2;
        // System.out.printf(sum);
        return mul;
    }

    //FACTORIAL
//NO FACTORIAL FOR -VE
//0!=1
//N!=N*(N-1)*(N-2)*....1
    public static void Factorialbasic(int n1) {

        int factorial=1;
        for(int i=n1;i>=1;i--){
            factorial=factorial*i;
        }
        System.out.println(factorial);

    }

    public static void main(String[] args) {
        /* Scanner sc=new Scanner(System.in);
        String name=sc.next();
printMyName(name);*/   //agr idhr sirf fun calling cmt kro to bhi cin krana parray ga cz of uper ki 2 lines
int num1=15;
int num2=2;
int s=printSum(num1, num2);
System.out.println("sum of n1 and n2 is:"+s);
        int m=printmul(num1, num2);
        System.out.println("Product of n1 and n2 is:"+m);
        Factorialbasic(num1);
    }

}

