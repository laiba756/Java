//1.
// Java Program to print
// line fill pattern

import java.util.*;
/* class GeeksForGeeks {

    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i;

        // outer loop to handle rows
        for (i = 0; i <= n; i++){

            // printing new line for each row
            System.out.println("*");
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/

// Java Program to print
// 2. Square fill pattern

import java.util.*;
/* class GeeksForGeeks {

    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i, j;

        // outer loop to handle rows
        for (i = 0; i <= n; i++) {

            // inner loop to handle columns
            for (j = 0; j <= n; j++) {
                System.out.print("*");
            }

            // printing new line for each row
            System.out.println();
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/

// Java Program to print pattern
//3.  Square hollow pattern
import java.util.*;

 /*class GeeksForGeeks {
    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i, j;
        // outer loop to handle number of rows
        for (i = 0; i <= n; i++) {
            // inner loop to handle number of columns
            for (j = 0; j <= n; j++) {
                // star will print only when it is in first
                // row or last row or first column or last
                // column
                if (i == 0 || j == 0 || i == n
                        || j == n ) {
                    System.out.print("*");
                }
                // otherwise print space only.
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/

// Java Program to print
// 4. Right half Pyramid pattern
import java.util.*;

/*class GeeksForGeeks {
    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i, j;

        // outer loop to handle rows
        for (i = 1; i <= n; i++) {

            // inner loop to handle columns
            for (j = 1; j <= i; j++) {
                System.out.print("*");
            }

            // printing new line for each row
            System.out.println();
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/

// Java Program to print pattern
//5.  Reverse Right Half Pyramid
import java.util.*;

/*class GeeksForGeeks {
    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i, j;

        // outer loop to handle rows
        for (i = n; i >= 1; i--) {

            // inner loop to handle columns
            for (j = 1; j <= i; j++) {
                System.out.print("*");
            }

            // printing new line for each row
            System.out.println();
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/

// Java Program to print pattern
//6.  Left Half Pyramid pattern
import java.util.*;

 /*class GeeksForGeeks {
    // Function to demonstrate pattern
    public static void printPattern(int n)
    {
        int i, j;

        // outer loop to handle rows
        for (i = 1; i <=n; i++) {

            // inner loop to print spaces.
            for (j = 1; j <=n-i; j++) {
                System.out.print(" ");
            }

            // inner loop to print stars.
            for (j = 1; j <= i; j++) {
                System.out.print("*");
            }

            // printing new line for each row
            System.out.println();
        }
    }

    // Driver Function
    public static void main(String args[])
    {
        int n = 6;
        printPattern(n);
    }
}*/








