//LOOPS
//*tumhari asani k liyay hi loops bnay gay hain

//***FOR***

/*package whatever //do not write package name here */
// 1. Java program to write a code in for loop from 1 to 10

/* class GFG {
    public static void main(String[] args)
    {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}*/

// 2. Java program to illustrate for loop.
/* class forLoopDemo {
    public static void main(String args[])
    {
        int sum = 0;

        // for loop begins
        // and runs till x <= 20
        for (int x = 1; x <= 10; x++) {
            sum = sum + x;
        }
        System.out.println("Sum: " + sum);
    }
}*/

// 3. Java infinite loop
/*class GFG {
    public static void main(String args[])
    {
        for (int i = 1; i >= 1; i++) {
            System.out.println("Infinite Loop " + i);
        }
    }
}*/

//4. infinite
/* class GFG {

    public static void main(String[] args)
    {
        for (;;) {
            System.out.println("infinitive loop");
        }
    }
}*/

// Java program to illustrate while loop.

/* class whileLoopDemo {
    public static void main(String args[])
    {
        // initialization expression
        int i = 1;

        // test expression
        while (i < 6) {
            System.out.println("Hello World");

            // update expression
            i++;
        }
    }
}*/

// Java program to illustrate while loop

/* class whileLoopDemo {
    public static void main(String args[])
    {
        int x = 1, sum = 0;

        // Exit when x becomes greater than 4
        while (x <= 10) {
            // summing up x
            sum = sum + x;

            // Increment the value of x for
            // next iteration
            x++;
        }
        System.out.println("Summation: " + sum);
    }
}*/

//7. Java Program to Illustrate One Time Iteration
// Inside do-while Loop
// When Condition IS Not Satisfied

// Class
/*class GFG {

    // Main driver method
    public static void main(String[] args)
    {
        // initial counter variable
        int i = 1;

        do {

            // Body of loop that will execute minimum
            // 1 time for sure no matter what
            System.out.println("Print statement");
            i++;
        }

        // Checking condition
        // Note: It is being checked after
        // minimum 1 iteration
        while (i < 5);
    }
}*/

//8.  Java Program to Illustrate Do-while Loop

// Class
/*class GFG {

    // Main driver method
    public static void main(String args[])
    {

        // Declaring and initialization expression
        int i = 1;

        // Do-while loop
        do {

            // Body of do-while loop
            // Print statement
            System.out.println("Hello World");

            // Update expression
            i++;
        }

        // Test expression
        while (i < 6);
    }
}*/

// 10. Java Program to Illustrate Do-while Loop

// Class
/* class GFG {

    // Main driver method
    public static void main(String args[])
    {
        // Declaring and initializing integer values
        int x = 21, sum = 0;

        // Do-while loop
        do {

            // Execution statements(Body of loop)

            // Here, the line will be printed even
            // if the condition is false
            sum += x;
            x--;
        }// x-- kro jb tk wo 21 say 11 na ho jay

        // Now checking condition
        while (x > 10);

        // Summing up
        System.out.println("Summation: " + sum);
    }
}*/

/*package whatever //do not write package name here */
//11. do-while without curly braces

import java.io.*;

/*class GFG {
    public static void main (String[] args) {
        int i=1;
        do{
         // only single statement in do block
            System.out.println("Hello GFG!");
        //System.out.println("bye");
                //***agr bye likho gay to run hi nahi ho ga
            // this condition is false so only do block will execute
                i++;}  //agr yh aur sath curly bracket na lagain to infinite loop
        while(i<3);  //agr i>=3 without curly bracket to aik bar execute hogi


    }
}*/












